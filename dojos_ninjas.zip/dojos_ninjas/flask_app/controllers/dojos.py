from flask import render_template,request,redirect,session
from flask_app import app
from flask_app.models.dojo import Dojos

@app.route('/dojos', methods = ['GET'])
def dojos():
    todos_dojos = Dojos.todos_dojos()
    return render_template('dojos.html', todos_dojos=todos_dojos)

@app.route('/crear_dojo', methods=['POST'])
def creardojo():
    data = {
        "name":request.form['dojo_name']
    }
    Dojos.creardojo(data)
    return redirect('/dojos')

@app.route('/dojos/<int:dojos_id>', methods =['GET'])
def show_dojo(dojos_id):
    data = {"id":dojos_id}
    dojo = Dojos.obtener_un_dojo(data)
    ninjas_de_un_dojo = Dojos.obtener_ninjas_del_dojo(data)
    return render_template('show.html', dojo=dojo, ninjas_de_un_dojo = ninjas_de_un_dojo)