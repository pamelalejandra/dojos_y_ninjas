from flask import render_template,request,redirect
from flask_app import app
from flask_app.models.dojo import Dojos
from flask_app.models.ninja import Ninjas


@app.route('/ninjas', methods = ['GET'])
def formulario_ninja():
    todos_dojos = Dojos.todos_dojos()
    return render_template('ninjas.html', todos_dojos=todos_dojos)

@app.route('/crearninja', methods = ['POST'])
def crearninja():
    print(request.form)
    data = {
        'first_name':request.form['first_name'],
        'last_name':request.form['last_name'],
        'age':request.form['age'],
        'dojo_id':request.form['dojo'],
    }
    id_ninja = Ninjas.crearninja(data)
    return redirect(f'/dojos/{data["dojo_id"]}')